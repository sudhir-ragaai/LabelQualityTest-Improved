import argparse
import torch
import pandas as pd
from PIL import Image
from tqdm import tqdm
from transformers import AutoImageProcessor, AutoModel


class EmbeddingGenerator:
    """Generate image embeddings using Hugging Face DINOv2."""

    def __init__(self, hf_model_id: str = "facebook/dinov2-large"):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.hf_model_id = hf_model_id
        self.processor = AutoImageProcessor.from_pretrained(self.hf_model_id)
        self.model = AutoModel.from_pretrained(self.hf_model_id).to(self.device).eval()

    def _preprocess_image(self, image_path: str):
        """Load and preprocess image for DINOv2."""
        image = Image.open(image_path)
        if image.mode != "RGB":
            image = image.convert("RGB")
        inputs = self.processor(images=image, return_tensors="pt")
        return inputs

    def _get_embedding(self, image_path: str):
        """Get normalized embedding for a single image."""
        data = self._preprocess_image(image_path)
        with torch.no_grad():
            outputs = self.model(**{k: v.to(self.device) for k, v in data.items()})
            feats = outputs.pooler_output
            feats = torch.nn.functional.normalize(feats, dim=1)
        return feats[0].tolist()

    def generate_embeddings_for_csv(
        self,
        csv_path: str,
        output_path: str,
        image_path_col: str = "image_local_path",
        output_embed_col: str = "ImageEmbeddingDinov2",
    ):
        """Generate DINOv2 embeddings for all images in a CSV."""
        df = pd.read_csv(csv_path)

        embeddings = []
        for _, row in tqdm(
            df.iterrows(),
            total=len(df),
            desc="Generating embeddings (DINOV2)",
        ):
            image_path = row[image_path_col]
            embedding = self._get_embedding(image_path)
            embeddings.append(embedding)

        df[output_embed_col] = embeddings
        df.to_csv(output_path, index=False)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate DINOv2 embeddings for a CSV of image paths.")
    parser.add_argument("--csv-path", required=True, help="Input CSV file path.")
    parser.add_argument(
        "--output-path",
        help="Output CSV file path. Defaults to the same as --csv-path (in-place).",
    )
    parser.add_argument(
        "--image-path-col",
        default="LocalPath",
        help="Name of the CSV column containing image paths.",
    )
    parser.add_argument(
        "--output-embed-col",
        default="ImageVectorsM1",
        help="Name of the CSV column to write embeddings into.",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    input_csv = args.csv_path
    output_csv = args.output_path or args.csv_path

    generator = EmbeddingGenerator()
    generator.generate_embeddings_for_csv(
        input_csv,
        output_csv,
        image_path_col=args.image_path_col,
        output_embed_col=args.output_embed_col,
    )


if __name__ == "__main__":
    main()



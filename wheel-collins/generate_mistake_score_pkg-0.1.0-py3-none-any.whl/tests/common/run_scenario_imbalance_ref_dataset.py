from utils.utils import *
from raga import *
import datetime
from raga._tests import clustering, scenario_imbalance_ref_dataset
from typing import Optional, Dict, List


def run_scenario_imbalance_reference_cluster(
        dataset_name: str,
        reference_dataset: str,
        embedding: str = "ImageVectorsM1",
        num_clusters: int = 3,
    ):
    """
    Scenario Imbalance Reference Dataset test (cluster-level).

    Args:
        dataset_name: dataset name to evaluate (reference comparison mode)
        embedding: Embedding column name for clustering
        num_clusters: Number of clusters
        min_value: Minimum count threshold for "minimum_check"
    """
    run_name = f"Scenario-Imbalance-Ref-Cluster-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)


    rules = SBRules()
    rules.add(metric="js_divergence", ideal_distribution="reference_dataset")
    rules.add(metric="chi_squared_test", ideal_distribution="reference_dataset")

    # rules.add(metric="js_divergence", ideal_distribution="minimum_check", min_value=0.1)
    # rules.add(metric="chi_squared_test", ideal_distribution="minimum_check", min_value=0.1)


    binning_parameters = {
        "altitude": {"method": "equal_width", "bins": 5},  # Equal width binning for altitude
    }


    cls_default = clustering(
        test_session=test_session,
        dataset_name=dataset_name,
        method="k-means",
        embedding_col=embedding,
        level="image",
        args={"numOfClusters": num_clusters},
    )

    ref_cls_default = clustering(
        test_session=test_session,
        dataset_name=reference_dataset,
        method="k-means",
        embedding_col=embedding,
        level="image",
        args={"numOfClusters": num_clusters},
    )

    edge_case_detection = scenario_imbalance_ref_dataset(
        test_session=test_session,
        dataset_name=[dataset_name],
        Reference_dataset=str(reference_dataset),
        test_name=run_name,
        type="scenario_imbalance",
        output_type="reference_dataset_cluster",
        embedding=embedding,
        rules=rules,
        clustering=cls_default,
        ref_cluster=ref_cls_default,
        # binning_parameters=binning_parameters,
    )

    test_session.add(edge_case_detection)
    test_session.run()


def run_scenario_imbalance_reference_metadata(
        dataset_name: str,
        aggregation_levels: List[str] = ["Medications", "Symptoms", "ProviderSpecialty", "TriageaAcuity", "PrimaryLanguage", "InsuranceType", "FacilityLevel", "Country"],
        min_value: int = 50,
        reference_dataset: Optional[str] = None,
    ):
    """
    Scenario Imbalance Reference Dataset test (metadata-level).

    Args:
        dataset_names: dataset names to evaluate (reference comparison mode)
        aggregation_levels: Metadata fields to aggregate
        min_value: Minimum count threshold for "minimum_check"
    """
    run_name = f"Scenario-Imbalance-Ref-Metadata-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)


    rules = SBRules()

    rules.add(metric="js_divergence", ideal_distribution="reference_dataset")
    rules.add(metric="chi_squared_test", ideal_distribution="reference_dataset")

    # rules.add(metric="js_divergence", ideal_distribution="minimum_check", min_value=min_value)
    # rules.add(metric="chi_squared_test", ideal_distribution="minimum_check", min_value=min_value)

    # binning_parameters = {
    #     "altitude": {"method": "equal_width", "bins": 5},  # Equal width binning for altitude
    # }

    edge_case_detection = scenario_imbalance_ref_dataset(
        test_session=test_session,
        dataset_name=[str(dataset_name)],
        test_name=run_name,
        type="scenario_imbalance",
        output_type="min_check_metadata",
        rules=rules,
        aggregation_levels=aggregation_levels,
        # binning_parameters=binning_parameters,
        Reference_dataset=str(reference_dataset),
    )

    test_session.add(edge_case_detection)
    test_session.run()

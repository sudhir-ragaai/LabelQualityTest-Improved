from utils.utils import *
from raga import *
import datetime
from typing import Optional


def run_data_augmentation(
                          dataset_name: str,
                          test_name: Optional[str] = None) -> None:
    if test_name is None:
        test_name = f"DataAugmentation-{dataset_name}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"

    run_name = test_name
    test_session = get_test_session(run_name)

    # Uncomment the following lines to run the data augmentation test of your choice
    rules = DARules()
    rules.add(technique="Zoom", scale=2.0, Stage="A")
    rules.add(technique="RandomNoise", type="GaussianNoise", variance_limit=(5.0, 25.0), mean=0.0, p=0.5, Stage="B")
    rules.add(technique="Flip", type="HorizontalFlip", Stage="C")
    rules.add(technique="Flip", type="VerticalFlip", Stage="D")
    rules.add(technique= "Rotate", angle = 47, p= 0.7, Stage = "E")
    rules.add(technique= "RandomNoise", type="GaussianNoise", variance_limit = (7.0, 26.0), mean = 0.1, p = 0.4, Stage="F")
    rules.add(technique= "Crop", x_min = 0, y_min = 0, x_max = 128, y_max = 128, p = 1, Stage="G")
    # rules.add(technique= "Overlay", type= 'Rain', blurSize= [0,1], rainLevel= [0,1], intensity= [0,1], raindropLength= [0, 1], raindropWidth=  [0, 1], raindropCount=  [0, 1], Stage="H")
    rules.add(technique="Blur", type="GaussianBlur", blur_limit=(15, 35), p=1.0, Stage="H")
    rules.add(technique="RandomContrast",limit=0.3,p=1.0,Stage="I")
    rules.add(technique="RandomBrightness",limit=0.4, p=1.0,Stage="J")
    rules.add(technique="RandomNoise",type="ISONoise", color_shift=(0.01, 0.05),intensity=(0.1, 0.5), p=0.5,Stage="I")
    rules.add(technique="RandomNoise",type="MultiplicativeNoise",multiplier=(0.7, 1.3),per_channel=True,p=0.5,Stage="J")
    rules.add(technique="HueSaturationValue",hue_shift_limit=(-10, 10),sat_shift_limit=(-20, 20),val_shift_limit=(-15, 15),p=0.5,Stage="K")
    # rules.add(technique= 'Occlusions', type= 'object_insertion', object_url= 'url', select_region= 'annotation', Class= 'car', Stage="L")
    # rules.add(technique='Mislabelling', type= "random_flip", p= "0.5", Class= "car", Stage="M")
    # rules.add(technique="Mislabelling", type= "random" , Class='car', keep_original = "false", frequency = [0, 4], Stage="N")
    # rules.add(technique="Overlay",type='Fog',intensity= [0, 1], Stage= "O")
    # rules.add(technique= 'Occlusions',type='block_occlusion', Stage="P")
    # rules.add(technique="Brightness", type= 'gamma_correction', intensity= [0, 1], stage= "Q")
              

    edge_case_detection = data_augmentation_test(
        test_session=test_session,
        test_name=test_name,
        dataset_name=dataset_name,
        type="data_augmentation",
        sub_type="basic",
        output_type="image_data",
        rules=rules
    )

    test_session.add(edge_case_detection)
    test_session.run()

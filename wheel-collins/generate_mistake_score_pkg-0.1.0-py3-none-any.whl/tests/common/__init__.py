# Common tests shared across all task types doesn't need to be from any single task type like classification, detection, semantic

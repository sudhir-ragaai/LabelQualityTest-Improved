from utils.utils import *
from raga import *
import datetime
from typing import Optional, List, Dict
from raga._tests import clustering, entropy_analysis_test


def run_entropy_metadata(
        dataset_name: str,
        aggregation_levels: List[str] = ["Weather", "Scene", "TimeOfDay", "Temp"],
        shannon_threshold: float = 7.0,
    ):
    """Run Entropy Analysis test (metadata-only)."""

    run_name = f"Entropy-Metadata-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)

    rules = EntropyRules()
    rules.add(metric="shannon_entropy", metric_threshold=shannon_threshold)

    binning_parameters = {
        "Temp": {"min": 2, "max":70, "bins": 6} # Equal width binning
    }

    # binning_parameters = {
    #     "TimeOfDay": {"method": "equal_width", "bins": 5},  # Equal width binning for altitude
    # }


    _entropy_analysis_test = entropy_analysis_test(
        test_session=test_session,
        dataset_name=dataset_name,
        test_name=run_name,
        rules=rules,
        output_type="metadata",
        type="entropy_analysis",
        aggregation_levels=aggregation_levels,
        bin_params=binning_parameters,
    )

    test_session.add(_entropy_analysis_test)
    test_session.run()


def run_entropy_cluster(
        dataset_name: str,
        embedding: str = "ImageVectorsM1",
        num_clusters: int = 5,
        shannon_threshold: float = 4.0,
    ):
    """Run Entropy Analysis test (cluster-level)."""

    run_name = f"Entropy-Cluster-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)

    rules = EntropyRules()
    rules.add(metric="shannon_entropy", metric_threshold=shannon_threshold)

    cls_default = clustering(
        test_session=test_session,
        dataset_name=dataset_name,
        method="k-means",
        embedding_col=embedding,
        level="image",
        args={"numOfClusters": num_clusters}
    )

    _entropy_analysis_test = entropy_analysis_test(
        test_session=test_session,
        dataset_name=dataset_name,
        test_name=run_name,
        type="entropy_analysis",
        output_type="cluster",
        embedding=embedding,
        rules=rules,
        clustering=cls_default
    )
 
    test_session.add(_entropy_analysis_test)
    test_session.run()


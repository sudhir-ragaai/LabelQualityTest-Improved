from utils.utils import *
from raga import *
import datetime


def run_image_property_drift(reference_dataset_name: str,
                           eval_dataset_name: str,
                           test_name: str = None):
    """Run Image Property Drift Test for object detection.
    
    Args:
        reference_dataset_name: Name of the reference dataset
        eval_dataset_name: Name of the evaluation dataset
        test_name: Name of the test (auto-generated if None)
        output_type: Type of output for the test
    """
    
    if test_name is None:
        test_name = f"ImagePropertyDriftng29-{reference_dataset_name}-vs-{eval_dataset_name}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    run_name = f"ImagePropertyDriftng-{reference_dataset_name}-vs-{eval_dataset_name}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)
    
    rules = IPDRules()


    rules.add(metric="image-property-suite")

    
    edge_case_detection = image_property_drift(
        test_session=test_session,
        reference_dataset_name=reference_dataset_name,
        eval_dataset_name=eval_dataset_name,
        rules=rules,
        test_name=test_name,
        type="image-property-drift",
        output_type="image-data"
    )
    
    test_session.add(edge_case_detection)
    test_session.run()



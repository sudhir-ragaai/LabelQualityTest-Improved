from utils.utils import *
from raga import *
import datetime
from raga._tests import clustering


def run_scenario_imbalance(dataset_name: str,
                          output_type: str = "metadata",
                          js_divergence_threshold: float = 0.5,
                          chi_squared_threshold: float = 0.3,
                          num_clusters: int = 9,
                          aggregation_levels: list = None):
    """Run Scenario Imbalance Test for object detection.
    
    Args:
        dataset_name: Name of the dataset to test
        output_type: Either "cluster" or "metadata"
        js_divergence_threshold: Threshold for JS divergence metric
        chi_squared_threshold: Threshold for chi-squared test metric
        num_clusters: Number of clusters for cluster-level analysis
        aggregation_levels: List of metadata fields for metadata-level analysis
    """
    
    run_name = f"ScenarioImbalance-{dataset_name}-{output_type}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)
    
    rules = SBRules()
    rules.add(metric="js_divergence", ideal_distribution="uniform", metric_threshold=js_divergence_threshold)
    rules.add(metric="chi_squared_test", ideal_distribution="uniform", metric_threshold=chi_squared_threshold)
    
    if output_type == "cluster":
        # Clustering is required for cluster level
        cls_default = clustering(
            test_session=test_session,
            dataset_name=dataset_name,
            method="k-means",
            embedding_col="ImageVectorsM1",
            level="image",
            args={"numOfClusters": num_clusters}
        )
        
        edge_case_detection = scenario_imbalance(
            test_session=test_session,
            dataset_name=dataset_name,
            test_name=run_name,
            type="scenario_imbalance",
            output_type="cluster",
            embedding="ImageVectorsM1",
            rules=rules,
            clustering=cls_default
        ) 
    else:  # metadata level
        if aggregation_levels is None:
            aggregation_levels = ["Medications", "Symptoms", "ProviderSpecialty", "TriageaAcuity", "PrimaryLanguage", "InsuranceType", "FacilityLevel", "Country"]
            
        edge_case_detection = scenario_imbalance(
            test_session=test_session,
            dataset_name=dataset_name,
            test_name=run_name,
            type="scenario_imbalance",
            output_type="metadata",
            rules=rules,
            aggregationLevels=aggregation_levels
        )
    
    test_session.add(edge_case_detection)
    test_session.run()

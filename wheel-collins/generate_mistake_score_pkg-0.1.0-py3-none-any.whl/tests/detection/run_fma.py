from utils.utils import *
from raga import *
import datetime
from typing import Optional
from raga._tests import clustering, failure_mode_analysis

def run_fma(dataset_name: str,
                 model: str = "YOLO",
                 gt: str = "GT",
                 embedding_col: str = "ImageVectorsM1",
                 num_clusters: int = 9,
                 precision_conf_threshold: float = 0.3,
                 precision_metric_threshold: float = 0.45,
                 precision_iou_threshold: float = 0.56,
                 f1_conf_threshold: float = 0.74,
                 f1_metric_threshold: float = 0.52,
                 f1_iou_threshold: float = 0.35,
                 recall_conf_threshold: float = 0.58,
                 recall_metric_threshold: float = 0.25,
                 recall_iou_threshold: float = 0.52,
                 run_name: Optional[str] = None) -> None:
    """
    Run Failure Mode Analysis test.
    
    Args:
        dataset_name: Name of the dataset to test
        model: Model column name
        gt: Ground truth column name
        embedding_col: Embedding column name
        num_clusters: Number of clusters for k-means
        precision_conf_threshold: Confidence threshold for precision
        precision_metric_threshold: Metric threshold for precision
        precision_iou_threshold: IoU threshold for precision
        f1_conf_threshold: Confidence threshold for F1 score
        f1_metric_threshold: Metric threshold for F1 score
        f1_iou_threshold: IoU threshold for F1 score
        recall_conf_threshold: Confidence threshold for recall 
        recall_metric_threshold: Metric threshold for recall
        recall_iou_threshold: IoU threshold for recall
    """
    if not run_name:
        run_name = f"FMATestng-{dataset_name}-{model}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)

    rules = FMARules()
    rules.add(metric="Precision", conf_threshold=precision_conf_threshold, 
              metric_threshold=precision_metric_threshold, iou_threshold=precision_iou_threshold, label="ALL")
    rules.add(metric="F1Score", conf_threshold=f1_conf_threshold, 
              metric_threshold=f1_metric_threshold, iou_threshold=f1_iou_threshold, label="ALL")
    rules.add(metric="Recall", conf_threshold=recall_conf_threshold, 
              metric_threshold=recall_metric_threshold, iou_threshold=recall_iou_threshold, label="ALL")

    cls_default = clustering(
        test_session=test_session, 
        dataset_name=dataset_name, 
        method="k-means", 
        embedding_col=embedding_col, 
        level="image", 
        args={"numOfClusters": num_clusters}, 
        force=True
    )

    edge_case_detection = failure_mode_analysis(
        test_session=test_session,
        dataset_name=dataset_name,
        test_name=run_name,
        model=model,
        gt=gt,
        rules=rules,
        output_type="object_detection",
        type="embedding",
        clustering=cls_default
    )
    
    test_session.add(edge_case_detection)
    test_session.run()

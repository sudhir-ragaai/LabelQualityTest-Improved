from raga import *
import datetime
import pandas as pd
from dotenv import load_dotenv
import os
import ast
import json
# Load environment variables
load_dotenv()

# Get environment variables
ACCESS_KEY = os.getenv('ACCESS_KEY')
SECRET_KEY = os.getenv('SECRET_KEY')
HOST = os.getenv('HOST')
PROJECT_NAME = os.getenv('PROJECT_NAME')
AWS_REGION = os.getenv('AWS_REGION')

def get_timestamp_x_hours_ago(hours):
    current_time = datetime.datetime.now()
    delta = datetime.timedelta(days=90, hours=hours)
    past_time = current_time - delta
    timestamp = int(past_time.timestamp())
    return timestamp

def image_classification(gt):
    """Robustly parse a label dict and return ImageClassificationElement.
    Accepts dict or stringified dict. If multiple keys, picks the max value.
    Safely handles NaN/invalid strings.
    """
    classification = ImageClassificationElement()

    # Parse input into a dict
    parsed = None
    if isinstance(gt, dict):
        parsed = gt
    else:
        if pd.isna(gt):
            return classification
        s = str(gt)
        try:
            parsed = json.loads(s)
        except Exception:
            try:
                parsed = ast.literal_eval(s)
            except Exception:
                return classification

    if not isinstance(parsed, dict) or len(parsed) == 0:
        return classification

    # Choose the label with highest confidence if multiple
    try:
        key, value = max(parsed.items(), key=lambda kv: float(kv[1]))
    except Exception:
        key, value = next(iter(parsed.items()))

    try:
        classification.add(key=key, value=float(value))
    except Exception:
        # Fallback without conversion
        classification.add(key=key, value=value)
    return classification

def get_test_session(run_name=None):
    return TestSession(
        project_name=PROJECT_NAME,
        run_name=run_name,
        access_key=ACCESS_KEY, 
        secret_key=SECRET_KEY, 
        host=HOST
    )

def detection_annotation(row, col_name='AnnotationsV1'):
    AnnotationsV1 = ImageDetectionObject()
    annotation_json = json.loads(row[col_name].replace("'", '"'))

    if type(annotation_json) == type({}):
        annotation_json = annotation_json["annotations"]

    for idx, detection in enumerate(annotation_json):
        AnnotationsV1.add(
            ObjectDetection(
                Id=detection["Id"],
                ClassId=detection["ClassId"],
                ClassName=detection["ClassName"],
                Confidence=float(detection["Confidence"]),
                BBox=detection["BBox"],
                Format="xywh_normalized",
            )
        )
    return AnnotationsV1

def replace_embedding(x):
    embeddings = ImageEmbedding()
    # Parse the string representation of the list
    if isinstance(x, str):
        import ast
        try:
            embedding_list = ast.literal_eval(x)
        except:
            # If ast.literal_eval fails, try json.loads
            import json
            embedding_list = json.loads(x)
    else:
        embedding_list = x
    
    for embedding in embedding_list:
        embeddings.add(Embedding(embedding))
    return embeddings


def predictions_annotation(predictions_str):
    """Convert prediction string to detection annotation format"""
    AnnotationsV1 = ImageDetectionObject()
    
    if pd.isna(predictions_str) or predictions_str == '[]':
        return AnnotationsV1
    
    try:
        annotation_json = json.loads(predictions_str.replace("'", '"'))
        
        if type(annotation_json) == type({}):
            annotation_json = annotation_json["annotations"]
        
        for idx, detection in enumerate(annotation_json):
            AnnotationsV1.add(
                ObjectDetection(
                    Id=detection["Id"],
                    ClassId=detection["ClassId"],
                    ClassName=detection["ClassName"],
                    Confidence=float(detection["Confidence"]),
                    BBox=detection["BBox"],
                    Format="xywh_normalized",
                )
            )
    except Exception as e:
        print(f"Error processing detection: {e}")
    
    return AnnotationsV1


def to_azure(uri):
    AZ_BASE = "https://ragadev5prismstorage.blob.core.windows.net/raga-dev5-prism-blob-storage/images/bdd_val_1k/images"
    # AZ_BASE = "https://minio-raga.apps.arotest.westus2.aroapp.io/raga-bucket/images/brain_mri"
    if not isinstance(uri, str) or not uri:
        return uri
    name = uri.split("/")[-1]
    return AZ_BASE + "/" + name


def csv_parser_detections(csv_file):
    df = pd.read_csv(csv_file)
    data_frame = pd.DataFrame()

    df["ImageUri"] = df["LocalPath"].apply(to_azure)

    data_frame["ImageId"] = df["ImageId"].apply(lambda x: StringElement(x))
    data_frame["ImageUri"] = df["ImageUri"].apply(
        lambda x: StringElement(x)
    )
    data_frame["SourceLink"] = df["ImageUri"].apply(
        lambda x: StringElement(x)
    )
    data_frame["TimeOfCapture"] = df.apply(
        lambda row: TimeStampElement(get_timestamp_x_hours_ago(row.name)), axis=1
    )
    
    data_frame["AnnotationsV1"] = df.apply(detection_annotation, axis=1)

    data_frame["ImageVectorsM1"] = df["ImageEmbedding"].apply(
        lambda x: replace_embedding(x))

    data_frame["MistakeScore"] = df["MistakeScore"].apply(mistake_score)
    

    data_frame["DetectionPredictionsDETR"] = df["DetectionPredictionsDETR"].apply(
        lambda x: predictions_annotation(x))
    data_frame["DetectionPredictionsYOLO"] = df["DetectionPredictionsYOLO"].apply(
        lambda x: predictions_annotation(x))


    data_frame["Weather"] = df["Weather"].apply(lambda x: StringElement(x))
    data_frame["Scene"] = df["Scene"].apply(lambda x: StringElement(x))
    data_frame["TimeOfDay"] = df["TimeOfDay"].apply(lambda x: StringElement(x))

    return data_frame


def csv_parser_classification(csv_file):
    df = pd.read_csv(csv_file)
    data_frame = pd.DataFrame()
    data_frame["ImageId"] = df["id"].apply(lambda x: StringElement(x))
    data_frame["ImageUri"] = df["ImageUri"].apply(
        lambda x: StringElement(x)
    )
    data_frame["SourceLink"] = df["ImageUri"].apply(
        lambda x: StringElement(x)
    )
    data_frame["TimeOfCapture"] = df.apply(
        lambda row: TimeStampElement(get_timestamp_x_hours_ago(row.name)), axis=1
    )
    
    data_frame["AnnotationsV1"] = df.apply(detection_annotation, axis=1)

    data_frame["ImageVectorsM1"] = df["ImageEmbedding"].apply(
        lambda x: replace_embedding(x))

    data_frame["MistakeScore"] = df["MistakeScore"].apply(mistake_score)

    data_frame["Weather"] = df["Weather"].apply(lambda x: StringElement(x))
    data_frame["Scene"] = df["Scene"].apply(lambda x: StringElement(x))
    data_frame["TimeOfDay"] = df["TimeOfDay"].apply(lambda x: StringElement(x))

    data_frame["PRED"] = df["Model_pred"].apply(image_classification)
    data_frame["GT"] = df["GT_labels"].apply(image_classification)

    return data_frame

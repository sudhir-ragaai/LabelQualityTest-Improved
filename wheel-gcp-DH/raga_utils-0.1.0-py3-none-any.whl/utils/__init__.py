"""
Utility package for RagaPrism testing.

Exposes image embedding utilities such as `generate_embedding`.
"""



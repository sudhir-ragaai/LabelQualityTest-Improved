from utils.utils import *
from raga import *
import datetime

def run_model_AB(dataset_name: str,
                      modelA: str = "DETR",
                      modelB: str = "YOLO",
                      gt: str = "GT",
                      metric: str = "precision_diff_all",
                      IoU: float = 0.6,
                      threshold: float = 0.6,
                      conf_threshold: float = 0.6):
    """
    Run Model A vs B comparison test.
    
    Args:
        dataset_name: Name of the dataset to test
        modelA: Name of Model A column
        modelB: Name of Model B column
        gt: Ground truth column name
        metric: Metric to compare
        IoU: IoU threshold
        threshold: General threshold
        conf_threshold: Confidence threshold
    """
    run_name = f"ModelABTest-{dataset_name}-{modelA}-vs-{modelB}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)

    rules = ModelABTestRules() 
    rules.add(metric=metric, IoU=IoU, _class="ALL", threshold=threshold, conf_threshold=conf_threshold)

    model_comparison_check = model_ab_test(
        test_session=test_session, 
        dataset_name=dataset_name,
        test_name=run_name,
        modelA=modelA, 
        modelB=modelB,
        type="labelled", 
        gt=gt,
        rules=rules,
    )

    test_session.add(model_comparison_check)
    test_session.run()

# if __name__ == "__main__":
#     import sys
#     dataset_name = sys.argv[1] if len(sys.argv) > 1 else "bdd100det"
#     run_model_ab_test(dataset_name=dataset_name)
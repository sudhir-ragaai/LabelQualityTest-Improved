from utils.utils import *
from raga import *
from typing import Dict

LABELMAP: Dict[int, str] = {"0":"car","1":"traffic sign","2":"traffic light","3":"bus","4":"truck","5":"rider","6":"person","7":"bike","8":"motor"}


def upload_dataset(dataset_name: str, dataset_path: str) -> None:
    """Upload a detection dataset into Raga with a standard schema.

    Expects CSV columns parsed by `csv_parser_detections` in `utils.utils`.

    Args:
        dataset_name: Name of the dataset to create/upload.
        dataset_path: Path to the CSV file.
    """

    pd_data_frame = csv_parser_detections(dataset_path)

    schema = RagaSchema()
    schema.add("ImageId", PredictionSchemaElement())
    schema.add("ImageUri", ImageUriSchemaElement())
    schema.add("TimeOfCapture", TimeOfCaptureSchemaElement())
    schema.add("SourceLink", FeatureSchemaElement())

    schema.add("ImageVectorsM1", ImageEmbeddingSchemaElement(model="GT"))
    schema.add("MistakeScore", MistakeScoreSchemaElement(ref_col_name="AnnotationsV1"))
    schema.add("AnnotationsV1", InferenceSchemaElement(model="GT",label_mapping=LABELMAP))
    schema.add("DetectionPredictionsDETR", InferenceSchemaElement(model="DETR", label_mapping=LABELMAP))
    schema.add("DetectionPredictionsYOLO", InferenceSchemaElement(model="YOLO", label_mapping=LABELMAP))
    
    schema.add("Weather", AttributeSchemaElement())
    schema.add("Scene", AttributeSchemaElement())
    schema.add("TimeOfDay", AttributeSchemaElement())

    cred = DatasetCreds(region=AWS_REGION)

    test_session = get_test_session()
    test_ds = Dataset(
        test_session=test_session,
        name=dataset_name,
        type=DATASET_TYPE.IMAGE,
        data=pd_data_frame,
        schema=schema,
        creds=cred,
    )

    # pd.DataFrame(test_ds.raga_extracted_dataset).to_csv(
    #     "test_detection_df_parsed.csv", index=False)
    test_ds.load()


if __name__ == "__main__":
    # Set just these two variables and run the script
    DATASET_NAME = "bdd_val_1k_final_test30_02dec"
    DATASET_PATH = "tests/bdd_val_1k_final_train70_cocoformat.csv"
    upload_dataset(DATASET_NAME, DATASET_PATH)
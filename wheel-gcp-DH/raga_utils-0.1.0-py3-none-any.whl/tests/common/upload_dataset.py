from utils.utils import *
from raga import *

LABELMAP = {
    0:'car',
    1:'traffic sign',
    2:'traffic light',
    3:'bus',
    4:'truck',
    5:'rider',
    6:'person',
    7:'bike',
    8:'motor',
}


def upload_dataset(dataset_name, dataset_path):
    pd_data_frame = csv_parser_classification(dataset_path)

    schema = RagaSchema()
    schema.add("ImageId", PredictionSchemaElement())
    schema.add("ImageUri", ImageUriSchemaElement())
    schema.add("TimeOfCapture", TimeOfCaptureSchemaElement())
    schema.add("SourceLink", FeatureSchemaElement())

    schema.add("ImageVectorsM1", ImageEmbeddingSchemaElement(model="GT"))
    schema.add("GT", ImageClassificationSchemaElement(model="GT", label_mapping=LABELMAP))
    schema.add("PRED", ImageClassificationSchemaElement(model="PRED", label_mapping=LABELMAP))
    
    schema.add("Weather", AttributeSchemaElement())
    schema.add("Scene", AttributeSchemaElement())
    schema.add("TimeOfDay", AttributeSchemaElement())

    cred = DatasetCreds(region=AWS_REGION)

    test_session = get_test_session()
    test_ds = Dataset(
        test_session=test_session,
        name=dataset_name,
        type=DATASET_TYPE.IMAGE,
        data=pd_data_frame,
        schema=schema,
        creds=cred,
    )
    test_ds.load()


if __name__ == "__main__":
    # Set just these two variables and run the script
    DATASET_NAME = "bdd1k_classfn"
    DATASET_PATH = "tests/bdd1k_classfn_cocoformat.csv"
    upload_dataset(DATASET_NAME, DATASET_PATH)

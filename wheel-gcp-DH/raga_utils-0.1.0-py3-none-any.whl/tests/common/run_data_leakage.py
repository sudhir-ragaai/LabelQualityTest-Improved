from utils.utils import *
from raga import *
import datetime


def run_data_leakage(train_dataset_name: str,
                     field_dataset_name: str,
                     metric_threshold: float = 2,
                     train_embed_col_name: str = "ImageVectorsM1",
                     embed_col_name: str = "ImageVectorsM1"):
    run_name = f"DataLeakageng-{train_dataset_name}-vs-{field_dataset_name}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    test_session = get_test_session(run_name)

    # rules = DLRules()
    rules = LQRules()
    rules.add(metric='overlapping_samples', metric_threshold=metric_threshold)

    edge_case_detection = data_leakage_test(
        test_session=test_session,
        test_name=run_name,
        train_dataset_name=train_dataset_name,
        dataset_name=field_dataset_name,
        # train_dataset_name="brain_mri_train",
        # dataset_name=" brain_mri_test",
        type="data_leakage",
        output_type="image_data",
        train_embed_col_name=train_embed_col_name,
        embed_col_name=embed_col_name,
        rules=rules
    )

    test_session.add(edge_case_detection)
    test_session.run()
